package UI;

public enum ResourcesType_temp {
	brick(1),ore(2),wool(3),grain(4),lumber(5),nothing(6);
	
	ResourcesType_temp(int n){value = n;}
	public final int value;
}
